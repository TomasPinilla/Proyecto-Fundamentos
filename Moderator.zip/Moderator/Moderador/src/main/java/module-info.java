module org.example.moderador {
    requires javafx.controls;
    requires javafx.fxml;


    opens org.example.moderador to javafx.fxml;
    exports org.example.moderador;
}